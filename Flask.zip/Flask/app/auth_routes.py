from flask import Blueprint, request, render_template, redirect, url_for, flash, session
from .models import db, User
from .forms import LoginForm
from .security import bcrypt

bp = Blueprint("auth", __name__)

@bp.route("/login", methods=["GET","POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data.lower().strip()
        pw = form.password.data

        user = User.query.filter_by(email=email).first()
        ok = user and bcrypt.check_password_hash(user.password_hash, pw)

        if not ok:
            flash("Invalid email or password.", "danger") 
            return render_template("login.html", form=form), 401

        session.permanent = True

        flash("Logged in.", "success")
        return redirect(url_for("core.list_contacts"))
    return render_template("login.html", form=form)


@bp.route("/create-demo-user")
def create_demo_user():
    email = "demo@example.com"
    pw_hash = bcrypt.generate_password_hash("DemoPass123!").decode("utf-8")
    if not User.query.filter_by(email=email).first():
        u = User(email=email, password_hash=pw_hash)
        db.session.add(u)
        db.session.commit()
    return "Demo user created: demo@example.com / DemoPass123!"
