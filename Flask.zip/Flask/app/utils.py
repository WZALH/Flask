import bleach

def sanitize_notes(txt: str) -> str:
    if not txt:
        return ""
  
    return bleach.clean(txt, tags=[], attributes={}, strip=True)
