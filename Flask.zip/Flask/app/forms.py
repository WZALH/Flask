from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Email, Length, Regexp, Optional

PHONE_RE = r'^\+?[0-9\-\s]{7,20}$'

class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=255)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=8, max=128)])
    submit = SubmitField("Login")

class ContactForm(FlaskForm):
    full_name = StringField("Full Name",
        validators=[DataRequired(), Length(max=120), Regexp(r"^[A-Za-z0-9 '._-]+$")])
    email = StringField("Email",
        validators=[DataRequired(), Email(), Length(max=255)])
    phone = StringField("Phone",
        validators=[Optional(), Regexp(PHONE_RE, message="Invalid phone format")])
    notes = TextAreaField("Notes",
        validators=[Optional(), Length(max=2000)])
    submit = SubmitField("Save")
