from flask import Blueprint, render_template, redirect, url_for, flash
from sqlalchemy import text  
from .models import db, Contact
from .forms import ContactForm
from .utils import sanitize_notes

bp = Blueprint("core", __name__)

@bp.route("/")
def home():
    return redirect(url_for("core.list_contacts"))

@bp.route("/contacts")
def list_contacts():
   
    contacts = Contact.query.order_by(Contact.created_at.desc()).all()
    return render_template("contacts_list.html", contacts=contacts)

@bp.route("/contacts/create", methods=["GET","POST"])
def create_contact():
    form = ContactForm()
    if form.validate_on_submit():
        c = Contact(
            full_name=form.full_name.data.strip(),
            email=form.email.data.lower().strip(),
            phone=(form.phone.data or "").strip(),
            notes=sanitize_notes(form.notes.data),
        )
        db.session.add(c)
        db.session.commit()
        flash("Contact created securely.", "success")
        return redirect(url_for("core.list_contacts"))
    return render_template("contact_form.html", form=form)


@bp.route("/contacts/by-email/<email>")
def contact_by_email(email):
    stmt = text("SELECT * FROM contact WHERE email = :email")
    rows = db.session.execute(stmt, {"email": email}).mappings().all()

    return {"results": rows}

