from flask import render_template
from werkzeug.exceptions import HTTPException

def init_error_handlers(app):
    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def internal(e):
        
        return render_template("errors/500.html"), 500

    @app.errorhandler(Exception)
    def all_exceptions(e):
        code = 500
        if isinstance(e, HTTPException):
            code = e.code
        return render_template("errors/generic.html", code=code), code
