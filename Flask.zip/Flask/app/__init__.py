from datetime import timedelta
import os
from flask import Flask
from flask_wtf import CSRFProtect
from .models import db
from .errors import init_error_handlers
from .security import bcrypt

csrf = CSRFProtect()

def create_app():
    app = Flask(__name__)

    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "CHANGE_ME_LONG_RANDOM"),
        SQLALCHEMY_DATABASE_URI="sqlite:///app.db",
        SQLALCHEMY_TRACK_MODIFICATIONS=False,

  
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SECURE=True,  
        SESSION_COOKIE_SAMESITE="Lax",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=2),
    )

    db.init_app(app)
    bcrypt.init_app(app)
    csrf.init_app(app)
    init_error_handlers(app)

    from .routes import bp as core_bp
    from .auth_routes import bp as auth_bp
    app.register_blueprint(core_bp)
    app.register_blueprint(auth_bp)

    with app.app_context():
        db.create_all()

    return app
